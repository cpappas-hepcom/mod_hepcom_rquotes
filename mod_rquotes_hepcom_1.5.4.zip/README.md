Hepcom Rquotes Rotator Module for Joomla 1.5
============================================

###Requirements:

* Joomla 1.5
* Rquotes 1.5.4 or later
* jQuery must be present (we recommend plg_system_scjquery if you don't have it running otherwise)

###Download

[mod_rquotes_hepcom_1.5.4.zip](https://github.com/downloads/cpappas-hepcom/mod_hepcom_rquotes/mod_rquotes_hepcom_1.5.4.zip)


Credits
-------

author: Chris Pappas cpappas@hepcom.ca

version: 1.0


